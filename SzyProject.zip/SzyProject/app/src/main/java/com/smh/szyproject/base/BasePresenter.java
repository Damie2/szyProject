package com.smh.szyproject.base;

public interface BasePresenter {
}
