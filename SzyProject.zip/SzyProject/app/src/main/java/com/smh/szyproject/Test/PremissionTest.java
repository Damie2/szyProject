package com.smh.szyproject.Test;

import android.Manifest;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.hjq.permissions.OnPermission;
import com.hjq.permissions.Permission;
import com.hjq.permissions.XXPermissions;
import com.smh.szyproject.R;
import com.smh.szyproject.base.BaseActivity;
import com.smh.szyproject.utils.L;

import java.util.List;

import butterknife.BindView;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.RuntimePermissions;

//注解在其内部需要使用运行时权限的Activity或Fragment上
public class PremissionTest extends BaseActivity {

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    public void init(Bundle savedInstanceState) {
        numJewelsInStones("aA","aAAbbbb");
    }
    public int numJewelsInStones(String J, String S) {
        int[] s = new int[128];
        int count =0;
        char[] c1 = J.toCharArray();
        char[] c2 = S.toCharArray();
        for(char i:c1){
            L.e(""+i);

            s[i]=1;
        }
        for(char i:c2){
            if(s[i]==1){
                count++;
            }
        }
        return count;
    }

}
