package com.smh.szyproject.net;

import com.smh.szyproject.Constants;

public class ApiAddress {

    //base地址
    public final static String api = Constants.URL;

    public final static String sendVersion = "upfile";



}

