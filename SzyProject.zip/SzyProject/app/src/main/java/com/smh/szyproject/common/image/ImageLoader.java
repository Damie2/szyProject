package com.smh.szyproject.common.image;

import android.content.Context;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

public interface ImageLoader {


    /**
     * Show Image
     *
     * @param imageUrl
     * @param imageView
     */
    void displayImage(Context activity, String imageUrl, ImageView imageView);
    void displayImage(Fragment fragment, String imageUrl, ImageView imageView);
     void loadRound(Context context, String url, ImageView imageView);
    void loadRound(Context context, int resId, ImageView imageView);

    void loadCircle(Context context, String url, ImageView imageView);
    void loadCircle(Context context, int resId, ImageView imageView);
}
