package com.smh.szyproject;


public class Constants {

    //交互地址
    public static final String URL = "http://s3h5cdn.08sw.com";
    public static final String PACKAGENAME = "com.nine.swkj.spb3";

}
