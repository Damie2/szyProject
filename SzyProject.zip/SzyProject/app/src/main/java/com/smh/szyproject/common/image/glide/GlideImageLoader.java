package com.smh.szyproject.common.image.glide;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.widget.ImageView;


import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.smh.szyproject.common.image.ImageLoader;

import java.util.regex.Pattern;

/**
 * @author renyang
 * @date 2018/4/8
 */

public class GlideImageLoader implements ImageLoader {
    public GlideImageLoader() {
//        new GlideBuilder().setBitmapPool()
//        Glide.init(context, new GlideBuilder());
    }


    @Override
    public void displayImage(Context context, String imageUrl, ImageView imageView) {
        if (context instanceof Activity){
            Activity activity= (Activity) context;
            if (activity.isDestroyed()){
                return;
            }
        }
        if (!isInteger(imageUrl))
            Glide.with(context).load(imageUrl).into(imageView);
        else
            Glide.with(context).load(Integer.valueOf(imageUrl)).into(imageView);
    }

    @Override
    public void displayImage(Fragment fragment, String imageUrl, ImageView imageView) {
        if (!isInteger(imageUrl))
            Glide.with(fragment).load(imageUrl).into(imageView);
        else
            Glide.with(fragment).load(Integer.valueOf(imageUrl)).into(imageView);
    }


    public static boolean isInteger(String str) {
        if (TextUtils.isEmpty(str)){
            return false;
        }
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }

    @Override
    public void loadRound(Context context, String url, ImageView imageView) {
        if (context instanceof Activity){
            Activity activity= (Activity) context;
            if (activity.isDestroyed()){
                return;
            }
        }
        Glide.with(context).load(url).transform(new GlideRoundTransform(context, 6)).into(imageView);
    }

    @Override
    public void loadRound(Context context, int resId, ImageView imageView) {
        if (context instanceof Activity){
            Activity activity= (Activity) context;
            if (activity.isDestroyed()){
                return;
            }
        }
        Glide.with(context).load(resId).transform(new GlideRoundTransform(context, 6)).into(imageView);
    }

    @Override
    public void loadCircle(Context context, String url, ImageView imageView) {
        if (context instanceof Activity){
            Activity activity= (Activity) context;
            if (activity.isDestroyed()){
                return;
            }
        }
        if (!isInteger(url))
            Glide.with(context).load(url).transform(new GlideCircleTransform(context)).into(imageView);
        else
            loadCircle(context, Integer.valueOf(url), imageView);
    }

    @Override
    public void loadCircle(Context context, int resId, ImageView imageView) {
        if (context instanceof Activity){
            Activity activity= (Activity) context;
            if (activity.isDestroyed()){
                return;
            }
        }
        Glide.with(context).load(resId).transform(new GlideCircleTransform(context)).into(imageView);
    }
}
