package com.smh.szyproject;


import android.Manifest;
import android.os.Bundle;

import com.smh.szyproject.base.BaseActivity;
import com.smh.szyproject.utils.L;


public class MainActivity extends BaseActivity {


    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    public void init(Bundle savedInstanceState) {
        sort();
    }
    private void sort() {
        L.e("???");
    }
}
