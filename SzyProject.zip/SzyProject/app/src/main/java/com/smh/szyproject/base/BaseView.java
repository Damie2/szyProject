package com.smh.szyproject.base;

public interface BaseView<T>  {
}
