package com.smh.szyproject.mvp.bean;

public class TestBean {
}
